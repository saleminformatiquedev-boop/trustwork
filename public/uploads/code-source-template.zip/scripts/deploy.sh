#!/bin/bash
echo "Déploiement en cours..."
npm run build && pm2 restart all
